#!/bin/sh
cd program_files
./PHITS_DYMC