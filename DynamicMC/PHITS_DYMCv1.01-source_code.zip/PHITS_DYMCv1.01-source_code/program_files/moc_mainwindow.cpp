/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[25];
    char stringdata0[642];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 32), // "on_horizontalSlider_valueChanged"
QT_MOC_LITERAL(2, 44, 0), // ""
QT_MOC_LITERAL(3, 45, 5), // "value"
QT_MOC_LITERAL(4, 51, 30), // "on_verticalSlider_valueChanged"
QT_MOC_LITERAL(5, 82, 34), // "on_horizontalSlider_2_valueCh..."
QT_MOC_LITERAL(6, 117, 32), // "on_verticalSlider_2_valueChanged"
QT_MOC_LITERAL(7, 150, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(8, 174, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(9, 196, 32), // "on_verticalSlider_3_valueChanged"
QT_MOC_LITERAL(10, 229, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(11, 253, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(12, 277, 34), // "on_horizontalSlider_3_valueCh..."
QT_MOC_LITERAL(13, 312, 34), // "on_horizontalSlider_4_valueCh..."
QT_MOC_LITERAL(14, 347, 34), // "on_horizontalSlider_5_valueCh..."
QT_MOC_LITERAL(15, 382, 34), // "on_horizontalSlider_6_valueCh..."
QT_MOC_LITERAL(16, 417, 32), // "on_verticalSlider_4_valueChanged"
QT_MOC_LITERAL(17, 450, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(18, 474, 21), // "on_checkBox_2_clicked"
QT_MOC_LITERAL(19, 496, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(20, 520, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(21, 544, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(22, 568, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(23, 592, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(24, 617, 24) // "on_pushButton_11_clicked"

    },
    "MainWindow\0on_horizontalSlider_valueChanged\0"
    "\0value\0on_verticalSlider_valueChanged\0"
    "on_horizontalSlider_2_valueChanged\0"
    "on_verticalSlider_2_valueChanged\0"
    "on_pushButton_3_clicked\0on_pushButton_clicked\0"
    "on_verticalSlider_3_valueChanged\0"
    "on_pushButton_4_clicked\0on_pushButton_2_clicked\0"
    "on_horizontalSlider_3_valueChanged\0"
    "on_horizontalSlider_4_valueChanged\0"
    "on_horizontalSlider_5_valueChanged\0"
    "on_horizontalSlider_6_valueChanged\0"
    "on_verticalSlider_4_valueChanged\0"
    "on_pushButton_5_clicked\0on_checkBox_2_clicked\0"
    "on_pushButton_6_clicked\0on_pushButton_7_clicked\0"
    "on_pushButton_8_clicked\0on_pushButton_9_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_11_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  124,    2, 0x0a /* Public */,
       4,    1,  127,    2, 0x0a /* Public */,
       5,    1,  130,    2, 0x08 /* Private */,
       6,    1,  133,    2, 0x08 /* Private */,
       7,    0,  136,    2, 0x08 /* Private */,
       8,    0,  137,    2, 0x08 /* Private */,
       9,    1,  138,    2, 0x08 /* Private */,
      10,    0,  141,    2, 0x08 /* Private */,
      11,    0,  142,    2, 0x08 /* Private */,
      12,    1,  143,    2, 0x08 /* Private */,
      13,    1,  146,    2, 0x08 /* Private */,
      14,    1,  149,    2, 0x08 /* Private */,
      15,    1,  152,    2, 0x08 /* Private */,
      16,    1,  155,    2, 0x08 /* Private */,
      17,    0,  158,    2, 0x08 /* Private */,
      18,    0,  159,    2, 0x08 /* Private */,
      19,    0,  160,    2, 0x08 /* Private */,
      20,    0,  161,    2, 0x08 /* Private */,
      21,    0,  162,    2, 0x08 /* Private */,
      22,    0,  163,    2, 0x08 /* Private */,
      23,    0,  164,    2, 0x08 /* Private */,
      24,    0,  165,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_horizontalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->on_verticalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_horizontalSlider_2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_verticalSlider_2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_pushButton_3_clicked(); break;
        case 5: _t->on_pushButton_clicked(); break;
        case 6: _t->on_verticalSlider_3_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_pushButton_4_clicked(); break;
        case 8: _t->on_pushButton_2_clicked(); break;
        case 9: _t->on_horizontalSlider_3_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->on_horizontalSlider_4_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_horizontalSlider_5_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_horizontalSlider_6_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_verticalSlider_4_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_pushButton_5_clicked(); break;
        case 15: _t->on_checkBox_2_clicked(); break;
        case 16: _t->on_pushButton_6_clicked(); break;
        case 17: _t->on_pushButton_7_clicked(); break;
        case 18: _t->on_pushButton_8_clicked(); break;
        case 19: _t->on_pushButton_9_clicked(); break;
        case 20: _t->on_pushButton_10_clicked(); break;
        case 21: _t->on_pushButton_11_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
