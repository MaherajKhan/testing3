We strongly recommend the users to run the present program on GNU/Linux 
operating system or at least run it on Windows Subsystem for Linux (WSL) 
to get the full features and to avoid any strange bugs/issues. 
Please note Windows is NOT our main development operating system and 
providing extensive support for Windows would be really tedious.

please go to program_files and run "PHITS_DYMC.exe".

Your run results will be saved under working_directory.

You can also plot organ tallies using our custom-made tally plotter under TallyPlot folder.

Please also refer to the user manual for more information.
